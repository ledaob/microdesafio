from setuptools import setup

setup(
    name = "fechas",
    version = "1.0",
    packages=['fechas'],
)